//
//  ViewController.swift
//  HW-RobEsposito-Assignment2
//
//  Created by Rob Esposito on 7/1/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit

class BillViewController: UIViewController {

//    MARK: Declarations
    
    @IBOutlet weak var billAmountTextField: UITextField!
    @IBOutlet weak var tipPercentageTextField: UITextField!
    @IBOutlet weak var numGuestsTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    
//    MARK: Actions
    
    @IBAction func changedAmountText(sender: UITextField) {
////        ideally, this function would strip all formatting and add currency formatting
////        currently, it only adds currency formatting. it won't handle a scenario where the bill isn't numeric
//        
//        if
//            let billAmount = billAmountTextField.text,
//            let dblbillAmount = Double(billAmount)
//        {
//            let curFormatter = NSNumberFormatter()
//            curFormatter.numberStyle = .CurrencyStyle
//            
//            billAmountTextField.text = curFormatter.stringFromNumber(dblbillAmount)
//        } else {
////        do something here if the bill amount isn't numeric
//        }
    }
//
    @IBAction func changedTipText(sender: UITextField) {
//        if
//            let tipPercentage = tipPercentageTextField.text,
//            let uintTipPercentage = UInt(tipPercentage)
//        {
//            tipPercentageTextField.text = String((NSNumberFormatterStyle(rawValue: uintTipPercentage)))
//        } else {
////          do something here if the bill amount isn't numeric
//        }
    }
    
    @IBAction func splitBillButton(sender: UIBarButtonItem) {
        if
            let billAmount = billAmountTextField.text,
            let tipAmount = tipPercentageTextField.text,
            let numGuests = numGuestsTextField.text,
            let dblBillAmount = Double(billAmount),
            let dblTipAmount = Double(tipAmount),
            let dblNumGuests = Double(numGuests)
        {
            if dblNumGuests == 0 {
                resultLabel.text = "Input error!"
                resultLabel.textColor = UIColor.redColor()
                return
            }
            
            let curFormatter = NSNumberFormatter()
            curFormatter.numberStyle = .CurrencyStyle
            
            let divide100: Double = 100
            
            let dblTipPercentage = dblTipAmount / divide100
            let splitAmount = (dblBillAmount + (dblBillAmount * dblTipPercentage)) / dblNumGuests
            
            resultLabel.text = curFormatter.stringFromNumber(splitAmount)
            resultLabel.textColor = UIColor.blackColor()
        } else {
            resultLabel.text = "Input error!"
            resultLabel.textColor = UIColor.redColor()
        }
    }
    
//    MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

