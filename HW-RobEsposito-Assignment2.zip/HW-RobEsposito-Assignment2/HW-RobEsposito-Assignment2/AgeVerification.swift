//
//  AgeVerification.swift
//  HW-RobEsposito-Assignment2
//
//  Created by Rob Esposito on 7/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class AgeVerificationController: UIViewController {
    
    //  MARK:  Declarations
    
    
    @IBOutlet weak var birthYearText: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    
    // MARK:  Actions
    
    @IBAction func verifyButton(sender: UIButton) {
        if
            let birthYear = birthYearText.text,
            let intBirthYear = Int(birthYear)
        {
            if intBirthYear < 1900 {
                resultLabel.text = "Were you really born in \(intBirthYear)?!"
                return
            }
            
            let currentYear: Int = 2016
            let age = currentYear - intBirthYear
            
            resultLabel.text = verifyAge(age)
        } else {
            resultLabel.text = handleErrors()
        }
    }
    
    func verifyAge(currentAge: Int) -> String {
        if currentAge >= 21 {
            return "You can drink, vote and drive!"
        } else if currentAge >= 18 {
            return "You can drive and vote!"
        } else if currentAge >= 16 {
            return "You can drive!"
        } else {
            return "You are such a baby!"
        }
    }
    
    func handleErrors() -> String {
        if birthYearText.text == "" {
            return "Enter your birth year!"
        } else {
            return "You must enter a numeric year!"
        }
    }
    
    //    MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
