//
//  GuessNumber.swift
//  HW-RobEsposito-Assignment2
//
//  Created by Rob Esposito on 7/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class GuessViewController: UIViewController {
    
    //  MARK:  Declarations
    
    @IBOutlet weak var guessText: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var countGuessesLabel: UILabel!
    
    let randomNum = arc4random_uniform(10) + 1
    var guessCount: Int = 0
    
    // MARK:  Actions
    
    @IBAction func guessButton(sender: UIButton) {
        if
            let guess = guessText.text,
            let intGuess = UInt32(guess)
        {
            if intGuess > 10 || intGuess < 1 {
                resultLabel.text = "Your guess must be between 1 and 10!"
            } else if intGuess == randomNum {
                resultLabel.text = "You guessed RIGHT!!!!"
            } else {
                resultLabel.text = "Try again, loser..."
                guessCount = guessCount + 1
                
                countGuessesLabel.text = "\(guessCount) guesses"
            }
            
        } else {
            resultLabel.text = "You must guess a number!"
        }
    }
    
    
    //    MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        countGuessesLabel.text = "\(guessCount) guesses"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
