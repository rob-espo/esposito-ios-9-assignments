//
//  Menu.swift
//  HW-RobEsposito-Assignment2
//
//  Created by Rob Esposito on 7/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class MenuViewController: UIViewController {
    
    
    //    MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
