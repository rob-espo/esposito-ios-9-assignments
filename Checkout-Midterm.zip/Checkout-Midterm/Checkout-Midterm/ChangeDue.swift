//
//  ChangeDue.swift
//  Checkout-Midterm
//
//  Created by Rob Esposito on 8/3/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

protocol ChangeDueViewControllerDelegate: class {
    func userDidMakePayment()
}

class ChangeDue: UIViewController {
    
    //    MARK: Declarations
    @IBOutlet weak var labelChangeDue: UILabel!
    
    weak var delegate: ChangeDueViewControllerDelegate?
    var dblChangeDue: Double = 0.0
    
    //    MARK: Lifecycle
    override func viewWillAppear(animated: Bool) {
        let currencyFormatter = NSNumberFormatter()
        currencyFormatter.numberStyle = .CurrencyStyle
        
        labelChangeDue.text = currencyFormatter.stringFromNumber(dblChangeDue)
    }
    
    @IBAction func doneButton(sender: AnyObject) {
        delegate?.userDidMakePayment()
        
        let presentingVC = self.presentingViewController!
        let navigationController = presentingVC is UINavigationController ? presentingVC as? UINavigationController : presentingVC.navigationController
        navigationController?.popToRootViewControllerAnimated(false)
        
        self.dismissViewControllerAnimated(true, completion: nil)
        
        
        
//        self .dismissViewControllerAnimated(true, completion: nil)
//        self .navigationController?.popToRootViewControllerAnimated(true)
    }
    
}
