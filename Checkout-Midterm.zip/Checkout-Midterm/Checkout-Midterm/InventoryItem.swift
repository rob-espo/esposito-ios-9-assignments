//
//  InventoryItem.swift
//  Checkout-Midterm
//
//  Created by Rob Esposito on 8/1/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class InventoryItem {
    
    let name: String
    let description: String
    let price: Double
    let salePrice: Double
    let onSale: Bool
    let image: UIImage
    
    init(name: String, description: String, price: Double, salePrice: Double, onSale: Bool, image: UIImage) {
        self.name = name
        self.description = description
        self.price = price
        self.salePrice = salePrice
        self.onSale = onSale
        self.image = image
    }
}
