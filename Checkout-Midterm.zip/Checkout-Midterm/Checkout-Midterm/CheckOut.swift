//
//  CheckOut.swift
//  Checkout-Midterm
//
//  Created by Rob Esposito on 8/3/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

protocol CheckOutViewControllerDelegate: class {
    func userDidCheckOut(items: [InventoryItem])
}

class CheckOutItems: UIViewController {
    
//    MARK: Declarations
    @IBOutlet weak var labelNumberOfItems: UILabel!
    @IBOutlet weak var labelTotalCost: UILabel!
    @IBOutlet weak var textCashTendered: UITextField!
    
    weak var delegate: CheckOutViewControllerDelegate?
    var shoppingCartItems = [InventoryItem]()
    var dblTotalCost: Double = 0.0
    var strCashTendered: String = ""
    var dblCashTendered: Double = 0.0
    var dblChangeAmount: Double = 0.0
    
//    MARK: Lifecycle
    override func viewWillAppear(animated: Bool) {
        labelNumberOfItems.text = String(shoppingCartItems.count)
        
        for item in shoppingCartItems {
            if item.onSale == true {
                dblTotalCost = dblTotalCost + item.salePrice
            } else {
                dblTotalCost = dblTotalCost + item.price
            }
        }
        
        let currencyFormatter = NSNumberFormatter()
        currencyFormatter.numberStyle = .CurrencyStyle
        
        labelTotalCost.text = currencyFormatter.stringFromNumber(dblTotalCost)
    }    
    
//    MARK: Actions
    @IBAction func checkOutButton(sender: AnyObject) {
        if let
            strCashTendered = textCashTendered.text,
            dblCashTendered = Double(strCashTendered) {
            
                dblChangeAmount = dblCashTendered - dblTotalCost
        } else {
            let alert = UIAlertController(title: "No Cash Tendered", message: "You haven't entered a cash amount. Please confirm cash tendered and try again.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Got it!", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            
            return
        }
    }
    
//    MARK: Segue
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "changeSegue" {
            if let changeViewController = segue.destinationViewController as? ChangeDue {
                changeViewController.delegate = self
                    
                changeViewController.dblChangeDue = dblChangeAmount
                }
            }
        }
}

extension CheckOutItems: ChangeDueViewControllerDelegate {
    func userDidMakePayment() {
        delegate?.userDidCheckOut(shoppingCartItems)
    }
}