//
//  SelectItems.swift
//  Checkout-Midterm
//
//  Created by Rob Esposito on 8/1/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit

protocol SelectItemsViewControllerDelegate: class {
    func userDidSelectItem(item: InventoryItem)
}

class SelectItems: UIViewController {
    
//    MARK: Declarations
    
    weak var delegate: SelectItemsViewControllerDelegate?
    
//    MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // POPULATE INVENTORY ITEMS ONTO SCREEN HERE -- LATER
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//    MARK: Actions
    
    @IBAction func cancelButton(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func fluffyBedButton(sender: AnyObject) {
        let purchaseItem = InventoryItem(name: "Fluffy Bed", description: "Even cats will want to sleep here", price: 45.99, salePrice: 45.99, onSale: false, image: UIImage(named: "imageDogBed")!)
        delegate?.userDidSelectItem(purchaseItem)
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func collarButton(sender: AnyObject) {
        let purchaseItem = InventoryItem(name: "Collar", description: "Studded leather collar", price: 20.00, salePrice: 16.99, onSale: true, image: UIImage(named: "imageCollar")!)
        delegate?.userDidSelectItem(purchaseItem)
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func squeakyToyButton(sender: AnyObject) {
        let purchaseItem = InventoryItem(name: "Squeaky Toy", description: "Dogs love this", price: 9.99, salePrice: 9.99, onSale: false, image: UIImage(named: "imageSqueakyToy")!)
        delegate?.userDidSelectItem(purchaseItem)
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func waterBowlButton(sender: AnyObject) {
        let purchaseItem = InventoryItem(name: "Water Bowl", description: "16oz bowl", price: 14.99, salePrice: 14.99, onSale: false, image: UIImage(named: "imageWaterBowl")!)
        delegate?.userDidSelectItem(purchaseItem)
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func dogLeashButton(sender: AnyObject) {
        let purchaseItem = InventoryItem(name: "Leash", description: "Polyester with hand grip", price: 25.00, salePrice: 25.00, onSale: false, image: UIImage(named: "imageLeash")!)
        delegate?.userDidSelectItem(purchaseItem)
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func customItemButton(sender: AnyObject) {
    }
}
