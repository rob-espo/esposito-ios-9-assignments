//
//  ViewController.swift
//  Checkout-Midterm
//
//  Created by Rob Esposito on 8/1/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit

class ShoppingCartViewController: UITableViewController {
    
    private var shoppingCartList = [InventoryItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //    MARK: Segues
    @IBAction func selectItemsButton(sender: UIButton) {
        let storyboard = UIStoryboard(name: "SelectItems", bundle: nil)
        
        if
            let selectItemsNavigationController = storyboard.instantiateViewControllerWithIdentifier("SelectItemsNavController") as? UINavigationController,
            let selectItemsViewController = selectItemsNavigationController.topViewController as? SelectItems {
            
                presentViewController(selectItemsNavigationController, animated: true) {
                    selectItemsViewController.delegate = self
                }
            }
        }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if shoppingCartList.count == 0 {
            let alert = UIAlertController(title: "Empty Shopping Cart", message: "You haven't selected any items! Please select your purchases before checking out.", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Got it!", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            
            return
        } else {
            if segue.identifier == "checkOutSegue" {
                if let checkOutViewController = segue.destinationViewController as? CheckOutItems {
                    checkOutViewController.delegate = self
                    
                    checkOutViewController.shoppingCartItems = shoppingCartList
                }
            }
        }
    }

    //    MARK: UITableView Data Source
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shoppingCartList.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("shoppingCartItemList", forIndexPath: indexPath)
        
        let purchaseItem = shoppingCartList[indexPath.row]
        let currencyFormatter = NSNumberFormatter()
        currencyFormatter.numberStyle = .CurrencyStyle
        
        if purchaseItem.onSale == true {
            cell.textLabel?.text = ("\(purchaseItem.name) -- ON SALE!")
            cell.detailTextLabel?.text = currencyFormatter.stringFromNumber(purchaseItem.salePrice)!
        } else {
            cell.textLabel?.text = ("\(purchaseItem.name)")
            cell.detailTextLabel?.text = currencyFormatter.stringFromNumber(purchaseItem.price)!
        }

        return cell
    }
}

extension ShoppingCartViewController: SelectItemsViewControllerDelegate {
    func userDidSelectItem(item: InventoryItem) {
        shoppingCartList.append(item)
        tableView.reloadData()
    }
}

extension ShoppingCartViewController: CheckOutViewControllerDelegate {
    func userDidCheckOut(items: [InventoryItem]) {
        shoppingCartList.removeAll()
        tableView.reloadData()
    }
}

