//
//  BarcodeReader_ViewController.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation

class BarcodeReaderViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    
    //    MARK: Declarations
    var session: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    //    var selectedProduct: Product?
    let metadataOutput = AVCaptureMetadataOutput()
    
    @IBOutlet weak var viewPreviewArea: UIView!
    
    
    //    MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(displayItemDetailView(_:)), name: "ProductNotification", object: nil)
        
        // Create a session object
        session = AVCaptureSession()
        
        // Set the captureDevice
        let videoCaptureDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
        
        // Create input object
        let videoInput: AVCaptureDeviceInput?
        
        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }
        
        // Add input to the session
        if session.canAddInput(videoInput) {
            session.addInput(videoInput)
        } else {
            scanningNotPossible()
        }
        
        // Add output to the session
        if session.canAddOutput(metadataOutput) {
            session.addOutput(metadataOutput)
            
            // Send captured data to the delegate object on the main queue
            metadataOutput.setMetadataObjectsDelegate(self, queue: dispatch_get_main_queue())
            
            // Set barcode type to EAN-13
            metadataOutput.metadataObjectTypes = [AVMetadataObjectTypeEAN13Code]
        } else {
            scanningNotPossible()
        }
        
        // Add previewLayer and have it show the video data
        previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.frame = viewPreviewArea.layer.bounds
        previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill
        viewPreviewArea.layer.addSublayer(previewLayer)
        
        // Begin the capture session
        session.startRunning()
    }
    
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//    }
//    
//    override func viewDidAppear(animated: Bool) {
//        super.viewDidAppear(animated)
//        
////        // check for authorization to use camera
////        if AVCaptureDevice.authorizationStatusForMediaType(AVMediaTypeVideo) == AVAuthorizationStatus.Authorized {
////            
////            //do stuff
////        }
//    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if session?.running == false {
            session.startRunning()
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        if session?.running == true {
            session.stopRunning()
        }
    }
    
    //    MARK: Capture AV Output
    func captureOutput(captureOutput: AVCaptureOutput!, didOutputMetadataObjects metadataObjects: [AnyObject]!, fromConnection connection: AVCaptureConnection!) {
        // Get the first object from the metadataObjects array
        if let barcodeData = metadataObjects.first {
            
            // Turn it into machine readable code
            let barcodeReadable = barcodeData as? AVMetadataMachineReadableCodeObject
            
            // Unwrap and send barcode as a string to barcodeDetected
            if let readableCode = barcodeReadable {
                barcodeDetected(readableCode.stringValue)
            }
            
            // Vibrate!
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
            
            session.stopRunning()
        }
    }
    
    //    MARK: CLEAN SCANNED BARCODE & PASS TO API LOOKUP
    func barcodeDetected(code: String) {
        
        // Remove trailing/leading spaces
        let trimmedCode = code.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet())
        let trimmedCodeString = "\(trimmedCode)"
        
        // Notify user that we've found something
        let alert = UIAlertController(title: "Found a Barcode!", message: trimmedCode , preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Search", style: UIAlertActionStyle.Destructive, handler: { action in
            
            // Send the DataService.searchUPC()
            DataService.searchUPC(trimmedCodeString)
            self.navigationController?.popViewControllerAnimated(true)
        }))
        
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    @IBAction func buttonCancelScan(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // Notes:  transition to item detail view when product is found
    func displayItemDetailView(notification: NSNotification) {
        // Transition to ItemDetailViewController
        let storyboard = UIStoryboard(name: "ItemDetail", bundle: nil)
        
        let itemDetailViewController = storyboard.instantiateViewControllerWithIdentifier("ItemDetailViewController")
        self.presentViewController(itemDetailViewController, animated: true, completion: nil)
    }
    
    //    MARK:  NO CAMERA
    func scanningNotPossible() {
        
        // let the user know that scanning isn't possible with the current device
        let alert = UIAlertController(title: "Unable to Scan", message: "Oops! This device isn't equipped with a camera.", preferredStyle: .Alert)
        alert.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
        presentViewController(alert, animated: true, completion: nil)
        
        session = nil
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    func checkAccessToCamera() {
        if AVCaptureDevice.authorizationStatusForMediaType(AVMediaTypeVideo) == AVAuthorizationStatus.Authorized {
            return
        } else {
            AVCaptureDevice.requestAccessForMediaType(AVMediaTypeVideo, completionHandler: { (granted :Bool) -> Void in
                if granted == true {
                    // User granted access
                    return
                } else {
                    // User rejected access
                    self.scanningNotPossible()
                }
            });
        }
    }
}


// Requesting Access to use camera
//if AVCaptureDevice.authorizationStatusForMediaType(AVMediaTypeVideo) ==  AVAuthorizationStatus.Authorized
//{
//    // Already Authorized
//}
//else
//{
//    AVCaptureDevice.requestAccessForMediaType(AVMediaTypeVideo, completionHandler: { (granted :Bool) -> Void in
//        if granted == true
//        {
//            // User granted
//        }
//        else
//        {
//            // User Rejected
//        }
//    });
// }