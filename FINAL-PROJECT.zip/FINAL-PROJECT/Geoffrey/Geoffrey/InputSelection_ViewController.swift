//
//  ViewController.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit

class InputSelectionViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func buttonScanBarcode(sender: UIButton) {
        // Display BarcodeReader ViewController
        let storyboard = UIStoryboard(name: "BarcodeReader", bundle: nil)
        
        let viewController = storyboard.instantiateViewControllerWithIdentifier("BarcodeReaderViewController") as UIViewController
        self.presentViewController(viewController, animated: true, completion: nil)
    }
    
    
    @IBAction func buttonEnterManually(sender: UIButton) {
        // Display ManualEntry View Controller
        
    }
    
    
    
    
    
    
    
    
    
    
    
// FIGURE OUT CODING TO ADD ACTION SHEET FOR SELECITNG INPUT OPTION
    
    //    func viewWillAppear() {
    //        //Display action sheets for selecting input SelectInputMethod
    //        let optionMenu = UIAlertController(title: nil, message: "Choose Input Option", preferredStyle: .ActionSheet)
    //
    //        let cameraAction = UIAlertAction(title: "Scan a Barcode", style: .Default, handler: {
    //            (alert: UIAlertAction!) -> Void in
    //            print("Scan a Barcode")
    //        })
    //
    //
    //        let manualAction = UIAlertAction(title: "Enter Manually", style: .Default, handler: {
    //            (alert: UIAlertAction!) -> Void in
    //            print("Enter Manually")
    //        })
    //
    //        optionMenu.addAction(cameraAction)
    //        optionMenu.addAction(manualAction)
    //
    //        self.presentViewController(optionMenu, animated: true, completion: nil)
    //    }

}