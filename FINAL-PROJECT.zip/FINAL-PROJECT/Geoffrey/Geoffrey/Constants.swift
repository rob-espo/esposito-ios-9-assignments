//
//  Constants.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation

// MARK: DataService
let UPCDB_KEY = "0fe1dbfb857451aa23227d927a4826d5"
let UPCDB_AUTH_URL = "http://api.upcdatabase.org/json/"  // NOTES:  full JSON request format: http://api.upcdatabase.org/json/APIKEY/CODE

// MARK: Categories
let catBeverages = "Beverages"
let catDriedFood = "Dried Food"
let catDryGoods = "Dry Goods"
let catHousehold = "Household"
let catPackagedGoods = "Packaged Goods"
let catPaperGoods = "Paper Goods"
let catPetSupplies = "Pet Supplies"
let catStorageItems = "Storage Items"
let catToiletries = "Toiletries"