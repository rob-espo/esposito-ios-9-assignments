//
//  ItemDetail_ViewController.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/6/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class ItemDetailViewController: UIViewController, UITextFieldDelegate {
    
    // MARK: Declarations
    
    @IBOutlet weak var textItemName: UITextField!
    @IBOutlet weak var textAlias: UITextField!
    @IBOutlet weak var textDescription: UITextField!
    
    // MARK: Lifecyle
    override func viewDidLoad() {
        textItemName.delegate = self
        textAlias.delegate = self
        textDescription.delegate = self
        
        self.hideKeyboardWhenTappedAround()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        let productInfo = Product(id: DataService.dataService.PRODUCT_ID_FROM_UPCDB, name: DataService.dataService.PRODUCT_NAME_FROM_UPCDB, alias: DataService.dataService.PRODUCT_ALIAS_FROM_UPCDB, description: DataService.dataService.PRODUCT_DESC_FROM_UPCDB, avgPrice: DataService.dataService.PRODUCT_AVG_PRICE_FROM_UPCDB)
            
            textItemName.text = productInfo.name
            textAlias.text = productInfo.alias
            textDescription.text = productInfo.description

        
        // Notes: not displaying these values right now:
        // DataService.dataService.PRODUCT_ID_FROM_UPCDB
        // DataService.dataService.PRODUCT_AVG_PRICE_FROM_UPCDB
        

    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {    // called when 'return' key pressed. return NO to ignore.
        if (textField == textItemName) {
            textAlias.becomeFirstResponder()
        } else if (textField == textAlias) {
            textDescription.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        
        return true;
    }
    
    
    @IBAction func buttonCancel(sender: AnyObject) {
        let presentingVC = self.presentingViewController!
        let navigationController = presentingVC is UINavigationController ? presentingVC as? UINavigationController : presentingVC.navigationController
        navigationController?.popToRootViewControllerAnimated(false)
        
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func buttonSave(sender: AnyObject) {
        //save code
    }
    
}
