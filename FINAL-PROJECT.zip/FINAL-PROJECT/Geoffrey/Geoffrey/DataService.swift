//
//  Data Service.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

//protocol DataServiceDelegate: class {
//    func foundAPIData(item: Product)
//}


class DataService {
    
    //    MARK:  DECLARATIONS
    
    static let dataService = DataService()
    
    private(set) var PRODUCT_ID_FROM_UPCDB = ""
    private(set) var PRODUCT_NAME_FROM_UPCDB = ""
    private(set) var PRODUCT_ALIAS_FROM_UPCDB = ""
    private(set) var PRODUCT_DESC_FROM_UPCDB = ""
    private(set) var PRODUCT_AVG_PRICE_FROM_UPCDB = ""
    
//    private var scannedProduct: Product


    //   MARK: CALL UPC API & PARSE RESPONSE
    static func searchUPC(codeNumber: String) {
        let upcDatabaseURL = "\(UPCDB_AUTH_URL)\(UPCDB_KEY)/\(codeNumber)"
        
        Alamofire.request(.GET, upcDatabaseURL)
            .validate()
            .responseJSON { response in
                switch response.result {
                    
                case .Success:
                    if let jsonResponse = response.result.value {
                        var json = JSON(jsonResponse)
                        
                        if json["valid"] == "false" {
                            //display error message to user that product wasn't found
                            print("ERROR -- product not found")
                        } else {
                            // unwrap product id
                            if let productID = json["number"].string {
                                self.dataService.PRODUCT_ID_FROM_UPCDB = productID
                            } else {
                                // not sure this condition exists. test for it
                                print("ERROR -- product exists, but not associated DB ID")
                                self.dataService.PRODUCT_ID_FROM_UPCDB = ""
                            }
                            
                            // unwrap product name
                            if let productName = json["itemname"].string {
                                self.dataService.PRODUCT_NAME_FROM_UPCDB = productName
                            } else {
                                self.dataService.PRODUCT_NAME_FROM_UPCDB = ""
                            }
                            
                            // unwrap product alias
                            if let productAlias = json["alias"].string {
                                self.dataService.PRODUCT_ALIAS_FROM_UPCDB = productAlias
                            } else {
                                self.dataService.PRODUCT_ALIAS_FROM_UPCDB = ""
                            }
                            
                            // unwrap product description
                            if let productDesc = json["description"].string {
                                self.dataService.PRODUCT_DESC_FROM_UPCDB = productDesc
                            } else {
                                self.dataService.PRODUCT_DESC_FROM_UPCDB = ""
                            }
                            
                            //unwrap product average price
                            if let productAvgPrice = json["avg_price"].string {
                                self.dataService.PRODUCT_AVG_PRICE_FROM_UPCDB = productAvgPrice
                            } else {
                                self.dataService.PRODUCT_AVG_PRICE_FROM_UPCDB = ""
                            }
                        }
                    } else {
                        // handle JSON response error
                        print("ERROR -- didn't unwrap response.result.value")
                    }
                    
                case .Failure(let error):
                    //handle error
                    print(error)
                }
                
                // Post a notification that we have Product data
                NSNotificationCenter.defaultCenter().postNotificationName("ProductNotification", object: nil)
        }
    }
    
}
