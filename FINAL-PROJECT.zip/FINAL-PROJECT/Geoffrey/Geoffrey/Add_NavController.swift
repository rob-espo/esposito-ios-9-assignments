//
//  Add_NavController.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/6/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class AddNavigationController: UINavigationController {
    
    
    @IBOutlet weak var tabPantry: UITabBarItem!
    
    
    override func viewDidLoad() {
        tabPantry.image = UIImage(named: "TB_Add-Highlighted")
        

    }
    
}

