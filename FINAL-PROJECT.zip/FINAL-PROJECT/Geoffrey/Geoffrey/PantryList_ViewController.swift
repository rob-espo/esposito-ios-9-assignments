//
//  PantryList_ViewController.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/6/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class PantryListViewController: UITableViewController {
    
    // MARK: Declarations
    @IBOutlet weak var outletTableViewTItle: UINavigationItem!
    var pantryCategory = ""
    
    // MARK: Lifecycle
    override func viewWillAppear(animated: Bool) {
        //code
    }
    
    override func viewDidLoad() {
        //code
        outletTableViewTItle.title = pantryCategory
    }
    
    // MARK: Actions
    @IBAction func buttonHome(sender: AnyObject) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func buttonSort(sender: AnyObject) {
        //show action sheet for sorting
    }
}
