//
//  Products.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/4/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation

class Product {
    
    private(set) var id: String!
    private(set) var name: String!
    private(set) var alias: String!
    private(set) var description: String!
    private(set) var avgPrice: String!
    
    init(id: String, name: String, alias: String, description: String, avgPrice: String) {
        self.id = id
        self.name = name
        self.alias = alias
        self.description = description
        self.avgPrice = avgPrice
    }
}

// Consider adding:
    //  - pictures (array)
    //  - category/subCategory
    //  - hasBarcode (boolean) -- to handle items that were manually created
    //  - itemAlert (boolean) -- does this product have a threshold limit that should alert the user?
    //  - threshold count (int) -- what is the minimum # of items allowed for this product before it alerts?
    //  - current count (int) -- how many of these items are in the inventory currently
    //  - custom (string) -- for user's notes/comments