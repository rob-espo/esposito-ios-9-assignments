//
//  PantryMain_ViewController.swift
//  Geoffrey
//
//  Created by Rob Esposito on 9/6/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import Foundation
import UIKit

class PantryMainViewController:  UIViewController, UISearchBarDelegate  {
    
    // MARK: Declarations
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var buttonOutletBeverages: UIButton!
    @IBOutlet weak var buttonOutletDriedFood: UIButton!
    @IBOutlet weak var buttonOutletDryGoods: UIButton!
    @IBOutlet weak var buttonOutletHousehold: UIButton!
    @IBOutlet weak var buttonOutletPackagedGoods: UIButton!
    @IBOutlet weak var buttonOutletPaperGoods: UIButton!
    @IBOutlet weak var buttonOutletPetSupplies: UIButton!
    @IBOutlet weak var buttonOutletStorageItems: UIButton!
    @IBOutlet weak var buttonOutletToiletries: UIButton!
    
    var searchActive = false
    
    // MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.showsCancelButton = false
        searchBar.delegate = self
    }
    
    // MARK: Search
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchActive = true
        cleanSearch()
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchActive = false
        cleanSearch()
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchActive = false
        cleanSearch()
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchActive = false
        cleanSearch()
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        searchActive = true
        cleanSearch()
        
        // TO DO: implement search logic
        print(searchText)
    }
    
    func cleanSearch() {
        if searchActive == true {
            // display cancel button for search
            searchBar.showsCancelButton = true
            
            // disable category buttons
            buttonOutletBeverages.userInteractionEnabled = false
            buttonOutletDriedFood.userInteractionEnabled = false
            buttonOutletDryGoods.userInteractionEnabled = false
            buttonOutletHousehold.userInteractionEnabled = false
            buttonOutletPackagedGoods.userInteractionEnabled = false
            buttonOutletPaperGoods.userInteractionEnabled = false
            buttonOutletPetSupplies.userInteractionEnabled = false
            buttonOutletStorageItems.userInteractionEnabled = false
            buttonOutletToiletries.userInteractionEnabled = false
            
        } else {
            // hide search-related elements
            searchBar.text = ""
            searchBar.showsCancelButton = false
            searchBar.endEditing(true)
            
            // re-enable category buttons
            buttonOutletBeverages.userInteractionEnabled = true
            buttonOutletDriedFood.userInteractionEnabled = true
            buttonOutletDryGoods.userInteractionEnabled = true
            buttonOutletHousehold.userInteractionEnabled = true
            buttonOutletPackagedGoods.userInteractionEnabled = true
            buttonOutletPaperGoods.userInteractionEnabled = true
            buttonOutletPetSupplies.userInteractionEnabled = true
            buttonOutletStorageItems.userInteractionEnabled = true
            buttonOutletToiletries.userInteractionEnabled = true
        }
    }
    
    // MARK: ACTIONS
    @IBAction func buttonBeverages(sender: AnyObject) {
        displayPantryListVC(catBeverages)
    }
    
    @IBAction func buttonDriedFood(sender: AnyObject) {
       displayPantryListVC(catDriedFood)
    }
    
    @IBAction func buttonDryGoods(sender: AnyObject) {
        displayPantryListVC(catDryGoods)
    }
    
    @IBAction func buttonHousehold(sender: AnyObject) {
        displayPantryListVC(catHousehold)
    }
    
    @IBAction func buttonPackagedGoods(sender: AnyObject) {
       displayPantryListVC(catPackagedGoods)
    }
    
    @IBAction func buttonPaperGoods(sender: AnyObject) {
        displayPantryListVC(catPaperGoods)
    }
    
    @IBAction func buttonPetSupplies(sender: AnyObject) {
        displayPantryListVC(catPetSupplies)
    }
    
    @IBAction func buttonStorageItems(sender: AnyObject) {
        displayPantryListVC(catStorageItems)
    }
    
    @IBAction func buttonToiletries(sender: AnyObject) {
        displayPantryListVC(catToiletries)
    }
    
    func displayPantryListVC(cat: String) {
        let storyboard = UIStoryboard(name: "PantryList", bundle: nil)
        
        if
            let pantryListNavigationController = storyboard.instantiateViewControllerWithIdentifier("PantryListNavigationController") as? UINavigationController,
            let pantryListViewController = pantryListNavigationController.topViewController as? PantryListViewController
        {
            switch(cat) {
            case catBeverages:
                pantryListViewController.pantryCategory = catBeverages
            case catDriedFood:
                pantryListViewController.pantryCategory = catDriedFood
            case catDryGoods:
                pantryListViewController.pantryCategory = catDryGoods
            case catHousehold:
                pantryListViewController.pantryCategory = catHousehold
            case catPackagedGoods:
                pantryListViewController.pantryCategory = catPackagedGoods
            case catPaperGoods:
                pantryListViewController.pantryCategory = catPaperGoods
            case catPetSupplies:
                pantryListViewController.pantryCategory = catPetSupplies
            case catStorageItems:
                pantryListViewController.pantryCategory = catStorageItems
            case catToiletries:
                pantryListViewController.pantryCategory = catToiletries
            default:
                print("\(cat)")
            }
            
            self.navigationController?.pushViewController(pantryListViewController, animated: true)
        }
    }
}