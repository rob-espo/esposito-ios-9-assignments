//
//  RecipeTableViewCell.swift
//  HW-RobEsposito-Assignment3
//
//  Created by Rob Esposito on 7/24/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit

class RecipeTableViewCell: UITableViewCell {

    @IBOutlet weak var recipeNameLabel: UILabel!
    @IBOutlet weak var recipeDescriptionLabel: UILabel!
    
}
