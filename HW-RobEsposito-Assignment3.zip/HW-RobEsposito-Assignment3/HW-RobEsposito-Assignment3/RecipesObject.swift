//
//  RecipesObject.swift
//  HW-RobEsposito-Assignment3
//
//  Created by Rob Esposito on 7/24/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit
import Foundation

class RecipeClass {
    
    let name: String
    let description: String
    let cookTime: String
    let servings: String
    let ingredients: [String]
    let instructions: [String]
    let picture: UIImage
    
    init (name: String, description: String, cookTime: String, servings: String, ingredients: [String], instructions: [String], picture: UIImage) {
        self.name = name
        self.description = description
        self.cookTime = cookTime
        self.servings = servings
        self.ingredients = ingredients
        self.instructions = instructions
        self.picture = picture
    }
}