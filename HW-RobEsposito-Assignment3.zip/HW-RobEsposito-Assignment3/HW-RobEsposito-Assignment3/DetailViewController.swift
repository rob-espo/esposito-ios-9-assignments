//
//  DetailViewController.swift
//  HW-RobEsposito-Assignment3
//
//  Created by Rob Esposito on 7/24/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit
import Foundation

class DetailViewController: UIViewController {

//    MARK: Declarations

    @IBOutlet weak var navTitleView: UINavigationItem!
    @IBOutlet weak var pictureImage: UIImageView!
    @IBOutlet weak var cookTimeLabel: UILabel!
    @IBOutlet weak var servingsLabel: UILabel!
    @IBOutlet weak var ingredientsLabel: UILabel!
    @IBOutlet weak var directionsLabel: UILabel!
    
    var recipeItem: RecipeClass?
    
    
//    MARK: Display data in DetailViewController
    
    override func viewWillAppear(animated: Bool) {
        if let recipeItem = recipeItem {
            navTitleView.title = recipeItem.name
            pictureImage.image = recipeItem.picture
            cookTimeLabel.text = recipeItem.cookTime
            servingsLabel.text = recipeItem.servings
            for ingredients in recipeItem.ingredients {
                ingredientsLabel.text = ingredientsLabel.text! + "\r\n \(ingredients)"
            }
            
            for instructions in recipeItem.instructions {
                directionsLabel.text = directionsLabel.text! + "\r\n \(instructions)"
            }
        }
    }
    
}