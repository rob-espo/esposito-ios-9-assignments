//
//  MainRecipeListViewController.swift
//  HW-RobEsposito-Assignment3
//
//  Created by Rob Esposito on 7/24/16.
//  Copyright © 2016 Rob Esposito. All rights reserved.
//

import UIKit

class RecipeTableViewController: UITableViewController {

//  MARK: Declarations
    private var recipeList = [RecipeClass]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//      MARK: Load data into array
        let listOfRecipes = [
            RecipeClass(name: "Chocolate Chip Cookies", description: "This is such an easy chocolate chip cookie. No special equipment, no creaming -- a perfect cookie to do with kids. We love how versatile this dough is, too.", cookTime: "1 hr 5 mins", servings: "30 cookies", ingredients: ["1/2 cup unsalted butter", "3/4 cup packed dark brown sugar", "3/4 cup sugar", "2 large eggs", "1 tsp vanilla extract", "12 oz semi-sweet chocolate chips", "2 1/4 cups all purpose flour", "3/4 tsp baking soda", "1 tsp salt"], instructions: ["Step 1: Evenly position 2 racks in the middle of the oven and preheat to 375 degrees F.", "Step 2: Line 2 baking sheets with parchment paper or silicone sheets.", "Step 3: Put the butter in a microwave safe bowl, cover and microwave on medium power until melted. Cool slightly.", "Step 4: Whisk the sugars, eggs, butter and vanilla in a large bowl until smooth.", "Step 5: Whisk the flour, baking soda and salt in another bowl.", "Step 6: Stir the dry ingredients into the wet ingredients with a wooden spoon; take care not to over mix.", "Step 7: Stir in the chocolate chips or chunks.", "Step 8: Scoop heaping tablespoons of the dough onto the prepared pans. Wet hands slightly and roll the dough into balls.", "Step 9: Space the cookies about 2-inches apart on the pans. Bake, until golden, but still soft in the center, 12 to 16 minutes, depending on how chewy or crunchy you like your cookies. Transfer hot cookies with a spatula to a rack to cool."], picture: UIImage(named: "imageCookies")!),
            RecipeClass(name: "Glazed Doughnuts", description: "Glazed", cookTime: "30 mins", servings: "Serves 4", ingredients: ["1 1/2 cups confectioners sugar", "3 1/2 Tbsp whole milk", "2 tsp vanilla extract", "5 cups vegetable oil", "1 cup milk", "1 large egg", "2 cups all purpose flour", "2 Tbsp sugar", "4 1/2 tsp baking powder", "1/2 tsp salt", "1/2 cup unsalted butter"], instructions: ["Step 1: Sift the confectioners' sugar into a medium bowl. Slowly stir in 3 tablespoons of milk and the vanilla extract until the mixture is smooth. If the glaze isn't thin enough, stir in 1 additional tablespoon of milk. Cover the glaze with plastic wrap and set it aside while you make the doughnut holes.", "Step 2: Add the vegetable oil to a large, heavy-bottomed pot. (There should be at least 2 inches of oil in the pot and at least 2 inches between the top of the oil and the top of the pot.) Attach the deep-fry thermometer to the pot and begin heating the oil over medium heat to 350ºF. Line a baking sheet with paper towels.", "Step 3: In a small bowl, whisk together the milk and the egg.", "Step 4: In a separate medium bowl, whisk together the flour, sugar, baking powder and salt. Stir the milk-egg mixture into the dry ingredients, then stir in the melted butter, mixing until a soft dough forms.", "Step 5: Once the oil has reached 350ºF, use a small ice cream scoop to drop about 1 tablespoon scoops of dough into the oil, careful not to overcrowd the pan. Fry the doughnut holes, flipping them in the oil, for about 2 minutes or until they're golden brown. Using a slotted spoon, transfer the doughnut holes to the paper towel-lined baking sheet.", "Step 6: Allow the doughnut holes to cool slightly. Place a cooling rack atop a baking sheet, then one by one, dip the doughnut holes into the glaze and transfer them to the rack to allow the excess glaze to drip off. Serve immediately."], picture: UIImage(named: "imageDoughnuts")!),
            RecipeClass(name: "Betty Crocker's Carrot Cake", description: "Try this classic cake recipe, and you’ll make it a permanent addition to your collection!", cookTime: "2 hours", servings: "Serves 8", ingredients: ["1 1/2 cups granulated sugar", "1 cup vegetable oil", "3 eggs", "2 cups all purpose flour", "2 tsp ground cinnamon", "1 tsp baking soda", "1 tsp vanilla extract", "1/2 tsp salt", "3 cups shredded carrots", "1 cup chopped walnuts", "8oz cream cheese", "1/4 cup butter", "3 tsp milk", "1 tsp vanilla", "4 cups powdered sugar"], instructions: ["Step 1: Heat oven to 350°F. Grease bottom and sides of one 13x9-inch pan or two 8-inch or 9-inch round pans with shortening; lightly flour. In large bowl, beat granulated sugar, oil and eggs with electric mixer on low speed about 30 seconds or until blended. Add flour, cinnamon, baking soda, 1 teaspoon vanilla and the salt; beat on low speed 1 minute. Stir in carrots and nuts. Pour into pan(s).", "Step 2: Bake 13x9-inch pan 40 to 45 minutes, round pans 30 to 35 minutes, or until toothpick inserted in center comes out clean. Cool rectangle in pan on cooling rack. Cool rounds 10 minutes; remove from pans to cooling rack. Cool completely, about 1 hour.", "Step 3: In medium bowl, beat cream cheese, butter, milk and vanilla with electric mixer on low speed until smooth. Gradually beat in powdered sugar, 1 cup at a time, on low speed until smooth and spreadable. Frost 13x9-inch cake or fill and frost round layers with frosting. Sprinkle nutmeg on frosted cake, if desired. Store in refrigerator."], picture: UIImage(named: "imageCarrotCake")!)
        ]
        
        recipeList.appendContentsOf(listOfRecipes)
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 100
    }
    
//    MARK: Populate tableView with data
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recipeList.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("recipeCell", forIndexPath: indexPath) as! RecipeTableViewCell
        
        cell.recipeDescriptionLabel.lineBreakMode = NSLineBreakMode.ByWordWrapping
        
        let recipeItem = recipeList[indexPath.row]
        cell.recipeNameLabel.text = recipeItem.name
        cell.recipeDescriptionLabel.text = recipeItem.description
        
        return cell
    }
    
//    MARK: Pass data to detailViewController
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let detailViewController = segue.destinationViewController as? DetailViewController {
            if let indexPath = tableView.indexPathForSelectedRow {
                let recipeItem = recipeList[indexPath.row]
                detailViewController.recipeItem = recipeItem
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

